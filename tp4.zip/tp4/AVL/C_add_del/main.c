#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include "analyzer.h"
#include "avl_tree.h"
int main()
{
	node *root=create();
	// Analyse du temps pris par les opérations.
	analyzer_t * time_analysis = analyzer_create();
	// Analyse du nombre de copies faites par les opérations.
	analyzer_t * copy_analysis = analyzer_create();
	// Analyse de l'espace mémoire inutilisé.
	analyzer_t * memory_analysis = analyzer_create(); 
	struct timespec before, after;
	clockid_t clk_id = CLOCK_REALTIME;
	float p;
	int p_aux;
	srand(time(NULL));
	for(int i = 100000; i > 0; i--){
	    p=rand()%100000;
	    // Ajout d'un élément et mesure du temps pris par l'opération.
	    clock_gettime(clk_id, &before);
	    if(p>50000){
		p_aux =p;
	    	root=insert(root,p);
	    }else{
		root=Delete(root,p_aux);
	    }
	    clock_gettime(clk_id, &after);
	    
	    // Enregistrement du temps pris par l'opération
	    analyzer_append(time_analysis, after.tv_nsec - before.tv_nsec);
	    // Enregistrement du nombre de copies efféctuées par l'opération.
	    // S'il y a eu réallocation de mémoire, il a fallu recopier tout le tableau.
	    analyzer_append(copy_analysis,i);
	    // Enregistrement de l'espace mémoire non-utilisé.
	    analyzer_append(memory_analysis,(root->capacity)-height(root));
	  }
	//SAUVEGARDES
	save_values(time_analysis, "../plots/avl_time_add_del.plot");
  	save_values(copy_analysis, "../plots/avl_copy_add_del.plot");
  	save_values(memory_analysis, "../plots/avl_memory_add_del.plot");

  // Nettoyage de la mémoire avant la sortie du programme
  //arraylist_destroy(a);
  analyzer_destroy(time_analysis);
  analyzer_destroy(copy_analysis);
  analyzer_destroy(memory_analysis);
  
return 0;
}
 

