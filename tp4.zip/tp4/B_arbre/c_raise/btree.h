
/*
 * Btree example for DynnOS
 *
 * Quenza simple license
 * 2013, Dinux
 *
 *
 */


/* 
** B-Tree definition :
** Assume the degree of the tree is d(d>=2).
**   1. Every node has at most 2d children.
**   2. Every node (except root) has at least d children.
**   3. The root has at least 2 children if it is not a leaf node.
**   4. A non-leaf node with K children contains K-1 keys. And :
**      K[1]<=K[2]<=K[3]<=...<=K[K-1].
**   5. All leaves appear in the same level.
*/

#include <stdio.h>
#include <stdlib.h>

#define TRUE 1
#define FALSE 0
#define EMPTY 0

#define NODE_ORDER		3 /*The degree of the tree.*/
#define NODE_POINTERS	(NODE_ORDER*2)
#define NODE_KEYS		NODE_POINTERS-1

typedef unsigned char bool;

typedef struct tree_node {
	int key_array[NODE_KEYS];
	struct tree_node *child_array[NODE_POINTERS];
	unsigned int key_index;
	bool leaf;
} node_t;

typedef struct {
	node_t *node_pointer;
	int key;
	bool found;
	unsigned int depth;
} result_t;

typedef struct {
	node_t *root;
	unsigned short order;
	bool lock;
	int capacity;
} btree_t;

static int BTreeGetLeftMax(node_t *T);
static int BTreeGetRightMin(node_t *T);
static node_t *create_node();
btree_t *create_btree();
static result_t *get_resultset();
void print_node(node_t *n);
result_t *search(int key, node_t *node);
static void split_child(node_t *parent_node, int i, node_t *child_array);
static void insert_nonfull(node_t *n, int key);
void insert(int key, btree_t *b);
static void merge_children(node_t *root, int index, node_t *child1, node_t *child2);
static void BTreeBorrowFromLeft(node_t *root, int index, node_t *leftPtr, node_t *curPtr);
static void BTreeBorrowFromRight(node_t *root, int index, node_t *rightPtr, node_t *curPtr);
static void BTreeDeleteNoNone(int X, node_t *root);
static int BTreeGetLeftMax(node_t *T);
static int BTreeGetRightMin(node_t *T);
void delete(int key, btree_t *b);
void tree_unlock(btree_t *r);
bool tree_lock(btree_t *r);
void console(btree_t *b);















