#include "btree.h"
#include <time.h>
#include "analyzer.h"

int main() {
	btree_t *root = create_btree();
	// Analyse du temps pris par les opérations.
	analyzer_t * time_analysis = analyzer_create();
	// Analyse du nombre de copies faites par les opérations.
	analyzer_t * copy_analysis = analyzer_create();
	// Analyse de l'espace mémoire inutilisé.
	analyzer_t * memory_analysis = analyzer_create(); 
	struct timespec before, after;
	clockid_t clk_id = CLOCK_REALTIME;
	float p;
	int p_aux;
	srand(time(NULL));
	for(int i = 0; i < 1000000; i++){
	    clock_gettime(clk_id, &before);
	    p=rand()%100000;
	    // Ajout d'un élément et mesure du temps pris par l'opération.
	    //if(p>50000){
            	insert(p,root);
		/*p_aux = p;
	    }else{
		delete(p_aux,root);
	    }*/
	    clock_gettime(clk_id, &after);
	    // Enregistrement du temps pris par l'opération
	    analyzer_append(time_analysis, after.tv_nsec - before.tv_nsec);
	    // Enregistrement du nombre de copies efféctuées par l'opération.
	    // S'il y a eu réallocation de mémoire, il a fallu recopier tout le tableau.
	    analyzer_append(copy_analysis,i);
	    // Enregistrement de l'espace mémoire non-utilisé.
	    analyzer_append(memory_analysis,(root->capacity)-(root->order));
	  }
	//SAUVEGARDES
	save_values(time_analysis, "../plots/btree_time_add_del.plot");
  	save_values(copy_analysis, "../plots/btree_copy_add_del.plot");
  	save_values(memory_analysis, "../plots/btree_memory_add_del.plot");

  // Nettoyage de la mémoire avant la sortie du programme
  //arraylist_destroy(a);
  analyzer_destroy(time_analysis);
  analyzer_destroy(copy_analysis);
  analyzer_destroy(memory_analysis);
  
        return 0;
}
