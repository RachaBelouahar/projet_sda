#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "analyzer.h"
#include "tasbinaire.h"

int main()
{
    tasbinaire *tas = tasbinaire_create();
   int i;
  // Analyse du temps pris par les opérations.
  analyzer_t * time_analysis = analyzer_create();
  // Analyse du nombre de copies faites par les opérations.
  analyzer_t * copy_analysis = analyzer_create();
  // Analyse de l'espace mémoire inutilisé.
  analyzer_t * memory_analysis = analyzer_create(); 
  struct timespec before, after;
  // utilisé comme booléen pour savoir si une allocation a été effectuée.
   float p;
   int memory_allocation=0;
   srand(time(NULL));
   for(i = 1; i <1000000 ; i++){
    timespec_get(&before, TIME_UTC);
    // Ajout d'un élément et mesure du temps pris par l'opération.
    memory_allocation=tasbinaire_append(tas,i);
    timespec_get(&after, TIME_UTC); 
    // Enregistrement du temps pris par l'opération
    analyzer_append(time_analysis, after.tv_nsec - before.tv_nsec);
    // Enregistrement du nombre de copies efféctuées par l'opération.
    // S'il y a eu réallocation de mémoire, il a fallu recopier tout le tableau.
    analyzer_append(copy_analysis,(memory_allocation)? i:1);
    // Enregistrement de l'espace mémoire non-utilisé.
    analyzer_append(memory_analysis,(tas->capacity)-(tas->size));
  }
  // Affichage de quelques statistiques sur l'expérience.
  fprintf(stderr, "Total cost: %lf\n", get_total_cost(time_analysis));
  fprintf(stderr, "Average cost: %lf\n", get_average_cost(time_analysis));
  fprintf(stderr, "Variance: %lf\n", get_variance(time_analysis));
  fprintf(stderr, "Standard deviation: %lf\n", get_standard_deviation(time_analysis));

  // Sauvegarde les données de l'expérience.
  save_values(time_analysis, "../plots/dynamic_array_time_croi.plot");
  save_values(copy_analysis, "../plots/dynamic_array_copy_croi.plot");
  save_values(memory_analysis, "../plots/dynamic_array_memory_croi.plot");

  // Nettoyage de la mémoire avant la sortie du programme
  tasbinaire_destroy(tas);
  analyzer_destroy(time_analysis);
  analyzer_destroy(copy_analysis);
  analyzer_destroy(memory_analysis);
  return EXIT_SUCCESS;
}

