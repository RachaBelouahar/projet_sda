#ifndef _TASBINAIRE_H
#define _TASBINAIRE_H

typedef struct
{
    int capacity;
    int size;
    int *tab;
}tasbinaire;

tasbinaire* tasbinaire_create(void);

void tasbinaire_append(tasbinaire *t, int value);

int tasbinaire_pop_back(tasbinaire *t);

void tasbinaire_destroy(tasbinaire *t);


#endif

