#include <stdlib.h>
#include <stdio.h>
#include "tasbinaire.h"

static void tasbinaire_realloc(tasbinaire *t);
static void tasbianire_reorganize(tasbinaire *t);

tasbinaire* tasbinaire_create(void)
{
    tasbinaire *t = malloc(sizeof(tasbinaire));
    if(!t) return NULL;
    t->tab = malloc(100000*sizeof(int));   /* Prévoir l'échec de malloc */
    t->capacity = 100000;
    t->size = 0;
    return t;
}

/***************************************************************************/
static void tasbinaire_realloc(tasbinaire *t)
{
    int new_size = 2*t->capacity;
    t->tab = realloc(t->tab, new_size*sizeof(int));
                                         /* Prévoir l'échec de realloc */
    t->capacity = new_size;
}

/***************************************************************************/
static void tasbianire_reorganize(tasbinaire *t)
{
    int tmp;
    int size = t->size;
    int index = size/2;
    while(t->tab[index] < t->tab[size] && size>1)
    {
        tmp = t->tab[size];
        t->tab[size] = t->tab[index];
        t->tab[index] = tmp;

        index/=2;
        size/=2;
    }
}

/***************************************************************************/
void tasbinaire_append(tasbinaire *t, int value)
{
    if(t->size >= t->capacity){ printf("\nattention le tas est saturé\n");return;}
    t->size++;
    t->tab[t->size] = value;
    tasbianire_reorganize(t);
}

/***************************************************************************/
int tasbinaire_pop_back(tasbinaire *t)
{
    int tmp;
    int indexUp = 1;
    int indexDn = 2;

    if(t->size==0) return -1;

    int value = t->tab[1];
    t->tab[1] = t->tab[t->size];
    t->size--;

    while(indexDn<=t->size)
    {
        if(indexDn+1 <= t->size && t->tab[indexDn] < t->tab[indexDn+1])
        {
            indexDn++;
        }
        if(t->tab[indexDn] > t->tab[indexUp])
        {
            tmp = t->tab[indexDn];
            t->tab[indexDn] = t->tab[indexUp];
            t->tab[indexUp] = tmp;
        }
        indexUp = indexDn;
        indexDn *= 2;
    }
    return value;
}

/***************************************************************************/
void tasbinaire_destroy(tasbinaire *t)
{
    free(t->tab);
    free(t);
}

